SideDoor = Class{__includes = Interactable}

function SideDoor:init(x, y, orientation)
    if orientation == 'right' then orientation = 'side-door-right'
    elseif orientation == 'left' then orientation = 'side-door-left' end
    Interactable.init(self, x, y, orientation, 30, 'z', SideDoor.use)
    self.open = false
    self.uiButton = nil
    self.wall = nil
    self.wallTemp = nil
    self.alwaysVisible = true
    self.animation.frame = 0
end

function SideDoor:update()
    Interactable.update(self)
    if self.uiButton then
        self.uiButton.inRange = self.inRange
    end
    if self.wall and self.animation.speed > 0 then
        local direction = (self.pos.x - player.pos.x > 0) and 1 or -1
        for i, pt in pairs(self.wall) do
            pt.x = self.pos.x + self.animation.frame * 20 * direction
        end
    end
    if not self.open then
        local dx = self.pos.x - player.pos.x
        if dx > 0 and dx < 10 then
            player.pos.x = self.pos.x - 10
        elseif dx < 0 and dx > -10 then
            player.pos.x = self.pos.x + 10
        end
    end
end

function SideDoor:use()
    self.animation.speed = 0.5
    if self.open then
        self.animation.reverse = true
        SoundSystem.queue('open_door')
        if self.wall then 
            for i, pt in pairs(self.wall) do pt.y = pt.y - 1000 end
        end
    else
        self.animation.reverse = false
        SoundSystem.queue('close_door')
    end
    if self.uiButton then self.uiButton.isActive = false end
    self.open = not self.open
    self.animation.callback = function()
        if self.uiButton then self.uiButton.isActive = true end
        self.isActive = true
        self.animation.speed = 0
        if self.open then self.animation.frame = 4
        else self.animation.frame = 0 end

        if self.wall and self.open then 
            for i, pt in pairs(self.wall) do pt.y = pt.y + 1000 end
        end
    end
end